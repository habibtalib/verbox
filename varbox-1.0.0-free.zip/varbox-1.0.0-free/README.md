# Varbox

The Laravel Admin panel we all want.

- [Visit Our Site](https://varbox.io) 
- [Create Account](https://varbox.io/register) 
- [Read The Docs](https://varbox.io/docs)
