{!! app('html')->script('vendor/varbox/js/app.js') !!}

@stack('scripts')
