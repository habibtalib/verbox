@if($message)
    <div class="flash {!! $type !!}">
        <p>{!! $message !!}</p>
    </div>
@endif