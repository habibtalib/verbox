<a href="{{ $url }}" class="btn btn-link mr-auto" {!! isset($attributes) ? implode(' ', $attributes) : '' !!}>
    Cancel
</a>
