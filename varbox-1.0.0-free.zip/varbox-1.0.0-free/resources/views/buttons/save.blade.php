<button type="submit" class="button-save btn btn-primary btn-square ml-4" {!! isset($attributes) ? implode(' ', $attributes) : '' !!}>
    <i class="fe fe-check mr-2"></i>Save
</button>
