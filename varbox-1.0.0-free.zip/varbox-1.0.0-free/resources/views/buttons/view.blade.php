<a href="{{ $url }}" class="button-view d-inline btn icon px-0 mx-2" data-toggle="tooltip" data-placement="top" title="View" {!! isset($attributes) ? implode(' ', $attributes) : '' !!}>
    <i class="fe fe-eye text-yellow"></i>
</a>
