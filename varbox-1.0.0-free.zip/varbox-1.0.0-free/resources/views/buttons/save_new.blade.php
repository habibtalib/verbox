<a class="button-save-new btn btn-warning btn-square text-white ml-4" {!! isset($attributes) ? implode(' ', $attributes) : '' !!}>
    <i class="fe fe-plus mr-2"></i>Save & New
</a>
