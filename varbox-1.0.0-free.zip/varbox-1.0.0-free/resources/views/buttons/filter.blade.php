{!! form()->button('<i class="fe fe-filter mr-2"></i>Filter', ['type' => 'submit', 'class' => 'button-filter btn btn-primary btn-square float-right']) !!}
