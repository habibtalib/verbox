<a href="{{ $url }}" class="btn text-blue mr-auto" {!! isset($attributes) ? implode(' ', $attributes) : '' !!}>
    <i class="fe fe-arrow-left mr-1"></i>Go Back
</a>
