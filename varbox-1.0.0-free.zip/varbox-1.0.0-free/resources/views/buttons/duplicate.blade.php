<a data-url="{{ $url }}" class="button-duplicate btn btn-yellow btn-square text-white ml-4" {!! isset($attributes) ? implode(' ', $attributes) : '' !!}>
    <i class="fe fe-copy mr-2"></i>Duplicate
</a>
