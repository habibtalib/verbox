<a href="{{ $url }}" class="button-add btn btn-primary btn-square btn-block" {!! isset($attributes) ? implode(' ', $attributes) : '' !!}>
    <i class="fe fe-plus mr-2"></i>Add New
</a>
