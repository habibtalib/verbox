<a href="{{ $url }}" class="button-download d-inline btn icon px-0 mr-2" data-toggle="tooltip" data-placement="top" title="Download" {!! isset($attributes) ? implode(' ', $attributes) : '' !!}>
    <i class="fe fe-download text-green"></i>
</a>
