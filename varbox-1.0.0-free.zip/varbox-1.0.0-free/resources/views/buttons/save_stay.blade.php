<a class="button-save-stay btn btn-success btn-square text-white ml-4" {!! isset($attributes) ? implode(' ', $attributes) : '' !!}>
    <i class="fe fe-map-pin mr-2"></i>Save & Stay
</a>
