<a data-url="{{ $url }}" class="button-save-draft btn btn-danger btn-square text-white ml-4" {!! isset($attributes) ? implode(' ', $attributes) : '' !!}>
    <i class="fe fe-paperclip mr-2"></i>Save As Draft
</a>
