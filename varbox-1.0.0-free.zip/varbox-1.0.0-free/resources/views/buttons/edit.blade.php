<a href="{{ $url }}" class="button-edit d-inline btn icon px-0 mx-2" data-toggle="tooltip" data-placement="top" title="Edit" {!! isset($attributes) ? implode(' ', $attributes) : '' !!}>
    <i class="fe fe-edit text-green"></i>
</a>
