<a data-url="{{ $url }}" class="button-preview btn btn-dark btn-square text-white ml-4" {!! isset($attributes) ? implode(' ', $attributes) : '' !!}>
    <i class="fe fe-eye mr-2"></i>Preview
</a>
