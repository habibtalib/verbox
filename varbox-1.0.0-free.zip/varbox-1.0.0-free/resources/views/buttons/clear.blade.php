<a class="button-filter-clear btn float-left"
   onclick="window.location.href = window.location.href.split('?')[0];"
    {!! isset($attributes) ? implode(' ', $attributes) : '' !!}
>
    Clear
</a>
