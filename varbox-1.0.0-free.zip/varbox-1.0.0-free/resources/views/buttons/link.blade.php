<a href="{{ $url }}" target="_blank" class="button-link d-inline btn icon px-0 mx-2" data-toggle="tooltip" data-placement="top" title="Go to link">
    <i class="fe fe-link text-blue"></i>
</a>
