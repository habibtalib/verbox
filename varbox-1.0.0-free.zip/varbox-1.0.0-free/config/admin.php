<?php

return [

    /*
    |
    | The prefix URL of the Admin section.
    |
    | For security purposes we suggest changing this to other than "admin".
    |
    */
    'prefix' => 'admin',

];
